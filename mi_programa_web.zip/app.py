from flask import Flask, request, render_template_string

app = Flask(__name__)

html = """
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Mi programa en línea</title>
</head>
<body>
    <h1>Ingresa tu nombre</h1>
    <form method="POST">
        <input name="nombre" placeholder="Tu nombre">
        <button type="submit">Enviar</button>
    </form>
    {% if nombre %}
        <h2>Hola, {{ nombre }}!</h2>
    {% endif %}
</body>
</html>
"""

@app.route("/", methods=["GET", "POST"])
def index():
    nombre = None
    if request.method == "POST":
        nombre = request.form.get("nombre")
    return render_template_string(html, nombre=nombre)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)